

/***************************** Include Files *******************************/
#include "complex_multiplier.h"

/************************** Function Definitions ***************************/
